<?php
    echo "<form action='tangkap.php' method='post' >".
    "<label> NIM : </label> <input type='text' name='nim'> <br>".
    "<label>Nama :</label> <input type='text' name='nama' > <br>".
    "<input type='submit' value='Simpan'>  <input type='reset' value='Kosongkan'>".
    "</form>";
?>