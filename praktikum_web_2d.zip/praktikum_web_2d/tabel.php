<table border="1" cellspacing="1">
        <tr>
            <th>No.</th>
            <th>Data</th>
        </tr>

<?php
    for ($i=0; $i<=5 ; $i++) { 
 ?>
        <tr>
            <td> <?php echo $i; ?> </td>
            <td> <?php echo 'Data Ke - '.$i; ?> </td>
        </tr>
   
<?php     
    }
?>
</table>

<table>
    <tr>
            <th>No.</th>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
    </tr>

    <?php
        $kode = ["B001","B002","B003","B004"];
        $namaBarang = ["Kopi","Gula","Permen","Beras"];
        $no=0;
        for ($i=0; $i <count($kode) ; $i++) { 
            $no++;
            if ($i % 2==0){
                $warna="background-color:red";
            }else{
                $warna="background-color:green";
            };
            echo "<tr style=' ".$warna." '>".
                "<td>".$no."</td>".
                "<td>".$kode[$i]."</td>".
                "<td>".$namaBarang[$i]."</td>".
            "</tr>";
        }
    ?>
</table>