<?php
echo "Ini adalah tombol Home";
?>