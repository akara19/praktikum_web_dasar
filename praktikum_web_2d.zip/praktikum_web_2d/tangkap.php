<?php
$nim = $_POST['nim'];
$nama = $_POST['nama'];

echo "Nim :". $nim."<br>";
echo "Nama : ".$nama."<br>";

echo "<a href='index.php?page=form' > Kembali </a>";
?>