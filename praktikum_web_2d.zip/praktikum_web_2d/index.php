<html>
    <title>Daspro WEB</title>
    <head>
    </head>
    <body>
        <table border="1"  width="100%">
            <tr >
                <td colspan="2">
                    <!-- <img src="header.jpeg" width="100%" height="50%"> -->
                    Header
                </td>
            </tr>
            <tr>
                <td width="25%">
                    <ul>
                        <li>
                            <a href="?page=home"> Home </a>
                        </li>
                        <li>
                            <a href="?page=profil"> Profil </a>
                        </li>
                        <li>
                            <a href="?page=form">Kirim Form </a>
                        </li>
                        <li>
                            <a href="?page=tabel">Tabel Dinamis</a>
                        </li>
                    </ul>
                </td>
                <td>
                    <?php
                       $page = $_GET['page'];
                      if ($page=='home') {
                            require_once('awal.php');
                      }else if ($page=='profil'){
                            require_once('profil.php');
                      }else if ($page=='form'){
                            require_once('form.php');
                      }else if ($page=='tabel'){
                            require_once('tabel.php');
                      };
                    ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">Footer</td>
            </tr>
        </table>
    </body>
</html>