/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : MySQL
 Source Server Version : 50716 (5.7.16-log)
 Source Host           : 127.0.0.1:3306
 Source Schema         : praktikum_web_2d

 Target Server Type    : MySQL
 Target Server Version : 50716 (5.7.16-log)
 File Encoding         : 65001

 Date: 14/12/2023 20:05:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for barang
-- ----------------------------
DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang`  (
  `Kode` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Stock` int(11) NULL DEFAULT NULL,
  `Harga_beli` int(11) NULL DEFAULT NULL,
  `Harga_jual` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Kode`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of barang
-- ----------------------------
BEGIN;
INSERT INTO `barang` (`Kode`, `Nama`, `Stock`, `Harga_beli`, `Harga_jual`) VALUES ('B002', 'Testing', 10, 1000, 1500);
COMMIT;

-- ----------------------------
-- Table structure for pembelian_detil
-- ----------------------------
DROP TABLE IF EXISTS `pembelian_detil`;
CREATE TABLE `pembelian_detil`  (
  `No_nota` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Kode_barang` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Harga_beli` int(11) NULL DEFAULT NULL,
  `Qty` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`No_nota`, `Kode_barang`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of pembelian_detil
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for pembelian_master
-- ----------------------------
DROP TABLE IF EXISTS `pembelian_master`;
CREATE TABLE `pembelian_master`  (
  `No_nota` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Tgl` date NULL DEFAULT NULL,
  `Kode_sup` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`No_nota`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of pembelian_master
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for penjualan_detil
-- ----------------------------
DROP TABLE IF EXISTS `penjualan_detil`;
CREATE TABLE `penjualan_detil`  (
  `No_nota` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Kode_barang` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Qty` int(11) NULL DEFAULT NULL,
  `Harga_beli` int(11) NULL DEFAULT NULL,
  `Harga_jual` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`No_nota`, `Kode_barang`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of penjualan_detil
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for penjualan_master
-- ----------------------------
DROP TABLE IF EXISTS `penjualan_master`;
CREATE TABLE `penjualan_master`  (
  `No_nota` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Tgl` date NULL DEFAULT NULL,
  PRIMARY KEY (`No_nota`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of penjualan_master
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for supplier
-- ----------------------------
DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier`  (
  `Kode` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Alamat` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Telp` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Kode`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of supplier
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
