<?php
    echo $nama."<br>";
    echo $alamat."<br>";
    echo $no_telp;
?>