<?php
    echo    "<table>";
            "<tr>".
            "<th>Kode</th>".
            "<th>Nama Barang</th>".
            "</tr>";
    foreach ($barang as $dataBarang){
        echo    "<tr>". 
                "<td>".$dataBarang->Kode."</td>".
                "<td>".$dataBarang->Nama."</td>".
                "</tr>";
    }
    echo "</table>";
?>