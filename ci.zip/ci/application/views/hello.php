<html>
    <h1>
    Hello, ini contoh view
    </h1>
</html>