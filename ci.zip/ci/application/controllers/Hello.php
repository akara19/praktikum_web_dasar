<?php

class Hello extends CI_Controller{

    public function index(){
        echo "Ini Contoh Controller Hello";
    }

    public function Hello_world(){
        echo "Hello World";
    }

    public function Load_view(){
        $this->load->view('hello');
    }

    public function Load_data(){
        $data['nama'] = "Adi";
        $data['alamat'] = "Jl. Nusa Indah No.16";
        $data['no_telp'] = "0123456789";

        $this->load->view('load_data',$data);

    }

}

?>