<?php
class Barang extends CI_Controller{

    public function index(){
        $data['barang'] = $this->db->get('barang')->result();
        
        $this->load->view('barang_tampil',$data);
    }

}


?>